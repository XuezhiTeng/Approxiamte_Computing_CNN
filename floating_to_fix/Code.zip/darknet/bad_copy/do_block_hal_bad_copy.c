#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <unistd.h>
#include <assert.h>

#define READ_CMD  (0x0 << 31)
#define WRITE_CMD (0x1 << 31)

volatile int det_int = 0;
void sighandler(int signo)
{
  if(signo==SIGIO)
    {
      det_int++;
      //printf("\nInterrupt detected\n");
    }
  
  return;
}













/////////////////////////////////////////////////////////////////////////


void do_block_hal (int lda,int ldb, int ldc, int M, int N, int K, int* A, int* B, int* C, int w_flag, int r_flag)
{
   //unsigned long volatile trig, val_A, val_B, result;
  unsigned long volatile gie, iie;
  unsigned long volatile trig;
  struct sigaction action;
  int fd;
  //printf("M=%d K=%d N=%d lda=%d ldb=%d ldc=%d\n",M,K,N,lda,ldb,ldc);
  //Ensure proper usage
  /*if(argc < 3)
  {
    printf("Usage: %s [valA] [valB]\n",argv[0]);
    return -1;
  }*/

  // install signal handler
  sigemptyset(&action.sa_mask);
  sigaddset(&action.sa_mask, SIGIO);

  action.sa_handler = sighandler;
  action.sa_flags=0;

  sigaction(SIGIO, &action, NULL);

  // open hardware device (driver)
  fd=open("/dev/fpga", O_RDWR);
  if(fd < 0)
  {

      printf("Unable to open /dev/fpga.  Ensure it exists!\n");
      return -1;
  }
  fcntl(fd, F_SETOWN, getpid());
  fcntl(fd, F_SETFL, fcntl(fd, F_GETFL)|O_ASYNC);

  // enable FPGA interrupts (global and IP)
  ioctl(fd, READ_CMD + 0x1, &gie);
  gie = gie | 0x00000001;
  ioctl(fd, WRITE_CMD + 0x1, &gie);

  iie = 0x1;
  ioctl(fd, WRITE_CMD + 0x2, &iie);

  /*// perform C += A*B;
  val_A = atol(argv[1]);
  val_B = atol(argv[2]);*/

  // write A
  /*ioctl(fd, WRITE_CMD + 0x4, &val_A);
  printf("A is %lu\n", val_A);*/


  //write lda
  ioctl(fd, WRITE_CMD + 0x4, &M);


  //write ldb
  ioctl(fd, WRITE_CMD + 0x6, &N);
  //write ldc
  ioctl(fd, WRITE_CMD + 0x8, &K);
  //write M
  //ioctl(fd, WRITE_CMD + 0xA, &M);
  //write N
  //ioctl(fd, WRITE_CMD + 0xC, &N);
  //write K
  //ioctl(fd, WRITE_CMD + 0xE, &K);


  int a, b, c,c0;
  int base = 0x1000;
  int unit = 0x2;
  int aa, bb, cc, cc0;
  for (a = 0; a < M; a++){
	  for (aa = 0;aa < K; aa++)
  	  ioctl(fd, WRITE_CMD + base + a*K+aa , &A[aa+a*lda]);
  }

  
  //write B
  base = 0x4000;
  for (b = 0; b < K; b++){
	  for (bb=0; bb < N; bb++)
      ioctl(fd, WRITE_CMD + base + bb+b*N , &B[bb+b*ldb]);
  }

  /*ioctl(fd, WRITE_CMD + 0x6, &val_B);
  printf("B is %lu\n", val_B);*/
   //write c
  if(w_flag == 1)
  {
	  base = 0x10000;
	  for (c = 0; c < M; c++){
		  for (cc=0;cc < N;cc++){
	      ioctl(fd, WRITE_CMD + base + cc+c*N , &C[cc+c*ldc]);
	  	}
		  //printf("%d\n",C[c*ldc]);
	  }
  }
  //printf("Block write ends.\n");

  
  // trigger MAC operation
  trig = 0x1;
  ioctl(fd, WRITE_CMD, &trig);

  // wait for interrupt
  while(!det_int) continue;

  // read result


   //read cout
  if(r_flag == 1)
  {
	  base = 0x10000;
	  for (c0 = 0; c0 < M; c0++){
		  for (cc0 = 0; cc0 <N;cc0++){
	      ioctl(fd, READ_CMD + base + cc0+c0*N , &C[c0*ldc+cc0]);
	  
	  /*ioctl(fd, READ_CMD + 0x8, &result);*/

	  	//printf("C += A*B is %d\n", C[c0*ldc+cc0]);
		  }
		  //printf("%d\n",C[c0*ldc]);
	  }
  }
 // printf("Block read ends.\n");
  //In the end, close the device driver
  close(fd);

 /* for (i = 0; i < M*N; ++i)   //Compare result of GEMM with the ideal value
  {
    if (Cout[i] != C_std[i]){
      printf("The GEMM function contains errors!\n");
      printf("Cout[i] =%d C_std[i] = %d",Cout[i],C_std[i]);
      printf("i = %d",i);
      exit(0);
    }
  }
  printf("The GEMM function works well!\n");

  return 0;
*/
 

}


