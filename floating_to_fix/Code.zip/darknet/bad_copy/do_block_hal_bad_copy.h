#ifndef DO_BLOCK_HAL_H
#define DO_BLOCK_HAL_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

void sighandler(int signo);
void do_block_hal (int lda,int ldb, int ldc, int M, int N, int K, int* A, int* B, int* C, int w_flag, int r_flag);

#endif
